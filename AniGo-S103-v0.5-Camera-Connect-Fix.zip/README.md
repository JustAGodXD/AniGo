# AniGo — S103 camera app

An intentionally simple Android viewer for the HomeEye S103 camera.

## Build the APK with GitHub

1. Create a new empty GitHub repository.
2. Upload **the contents of this folder** to the repository (not the outer ZIP itself).
3. Open the repository's **Actions** tab.
4. Select **Build AniGo APK**, then choose **Run workflow**.
5. Open the finished workflow and download the **AniGo-debug-APK** artifact.
6. Unzip that artifact on the phone and install `app-debug.apk`.

## What this first build does

- Opens Android Wi-Fi settings so the phone can join the camera's AP network.
- Tries common local RTSP paths at the S103's observed gateway, `192.168.0.1`.
- Times out and advances after six seconds instead of hanging forever on an unavailable path.
- Shows the live feed with Connect, Disconnect, and Fullscreen controls.
- Permanently blocks Android screenshots, screen recording, non-secure display capture,
  and the recent-apps preview while the app is visible. There is no off switch.
- Includes a full anime-styled account setup and returning-user sign-in screen.
- Stores the username and only a salted PBKDF2 password hash locally; the password itself is never stored.
- Requires sign-in again after AniGo is closed.
- Does not need internet access or a cloud account for local viewing.

## Important limitation

The S103's exact video protocol/stream path has not yet been confirmed. HomeEye may use a proprietary P2P protocol instead of RTSP. The app is structured so the camera connection layer can be replaced without redesigning the simple interface.

## Open and build

1. Unzip the project.
2. Open the `CameraSimple` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Connect an Android phone with USB debugging enabled.
5. Press Run.

For the camera test, connect the phone to the S103's Wi-Fi even if Android says the network has no internet. Turn off automatic switching to mobile data for that connection.
