package com.codibaker.camerasimple

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.codibaker.camerasimple.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var player: ExoPlayer? = null
    private var connected = false

    // Kept in one place so the exact S103 address can be changed after the first camera test.
    private val streamCandidates = listOf(
        "rtsp://192.168.4.1:554/live/ch00_0",
        "rtsp://192.168.4.1:554/live/ch0",
        "rtsp://192.168.4.1:554/stream1",
        "rtsp://192.168.4.1:554/live"
    )
    private var candidateIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!AppSession.unlocked) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSecure(true)

        binding.wifiButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
        }
        binding.connectButton.setOnClickListener {
            if (connected) disconnect() else connect()
        }
        binding.fullscreenButton.setOnClickListener { toggleFullscreen() }
    }

    private fun connect() {
        disconnect(showIdle = false)
        candidateIndex = 0
        connected = true
        binding.connectButton.text = "Disconnect"
        binding.status.visibility = View.VISIBLE
        binding.status.text = "Connecting…"
        tryCandidate()
    }

    private fun tryCandidate() {
        if (!connected) return
        if (candidateIndex >= streamCandidates.size) {
            binding.status.visibility = View.VISIBLE
            binding.status.text = "Camera found, but its video address needs one more setup step."
            return
        }
        player?.release()
        player = ExoPlayer.Builder(this).build().also { exo ->
            binding.playerView.player = exo
            exo.addListener(object : Player.Listener {
                private var advanced = false
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_READY) {
                        binding.status.visibility = View.GONE
                    }
                }
                override fun onPlayerError(error: PlaybackException) {
                    if (!advanced) {
                        advanced = true
                        candidateIndex++
                        tryCandidate()
                    }
                }
            })
            exo.setMediaItem(MediaItem.fromUri(streamCandidates[candidateIndex]))
            exo.prepare()
            exo.playWhenReady = true
            exo.volume = 0f
        }
    }

    private fun disconnect(showIdle: Boolean = true) {
        connected = false
        player?.release()
        player = null
        binding.playerView.player = null
        binding.connectButton.text = "Connect"
        if (showIdle) {
            binding.status.visibility = View.VISIBLE
            binding.status.text = "Disconnected"
        }
    }

    private fun setSecure(enabled: Boolean) {
        // Protects screenshots, recordings, non-secure mirroring and Recents previews.
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    private fun toggleFullscreen() {
        val hiding = binding.title.visibility == View.VISIBLE
        binding.title.visibility = if (hiding) View.GONE else View.VISIBLE
        binding.wifiButton.visibility = if (hiding) View.GONE else View.VISIBLE
        binding.connectButton.visibility = if (hiding) View.GONE else View.VISIBLE
        binding.privacyLabel.visibility = if (hiding) View.GONE else View.VISIBLE
        binding.fullscreenButton.text = if (hiding) "Exit" else "Fullscreen"
        if (hiding) window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        else window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
    }

    override fun onDestroy() {
        player?.release()
        if (isFinishing && !isChangingConfigurations) AppSession.unlocked = false
        super.onDestroy()
    }
}
