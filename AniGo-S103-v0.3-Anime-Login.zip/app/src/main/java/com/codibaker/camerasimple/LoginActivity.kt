package com.codibaker.camerasimple

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.codibaker.camerasimple.databinding.ActivityLoginBinding
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private val prefs by lazy { getSharedPreferences("anigo_private_setup", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        if (AppSession.unlocked) return openCamera()
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val setupDone = prefs.contains("password_hash")
        binding.screenTitle.text = if (setupDone) "WELCOME BACK, HERO" else "CREATE YOUR ANIGO ACCOUNT"
        binding.screenHint.text = if (setupDone)
            "Your next chapter is waiting"
        else "One-time setup • Your account stays on this device"
        binding.confirmPasswordLayout.visibility = if (setupDone) android.view.View.GONE else android.view.View.VISIBLE
        binding.actionButton.text = if (setupDone) "SIGN IN" else "CREATE ACCOUNT"

        binding.actionButton.setOnClickListener {
            binding.errorText.text = ""
            val username = binding.nameInput.text?.toString()?.trim().orEmpty()
            val password = binding.passwordInput.text?.toString().orEmpty()
            if (setupDone) login(username, password) else createSetup(
                username, password, binding.confirmPasswordInput.text?.toString().orEmpty()
            )
        }
    }

    private fun createSetup(username: String, password: String, confirmation: String) {
        if (username.length < 3) return showError("Choose a username with at least 3 characters.")
        if (password.length < 8) return showError("Use at least 8 characters for your password.")
        if (password != confirmation) return showError("Those passwords don't match.")
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs.edit()
            .putString("username", username)
            .putString("password_salt", Base64.getEncoder().encodeToString(salt))
            .putString("password_hash", Base64.getEncoder().encodeToString(hash(password, salt)))
            .apply()
        AppSession.unlocked = true
        openCamera()
    }

    private fun login(username: String, password: String) {
        val savedUsername = prefs.getString("username", "").orEmpty()
        val salt = Base64.getDecoder().decode(prefs.getString("password_salt", ""))
        val expected = Base64.getDecoder().decode(prefs.getString("password_hash", ""))
        if (!username.equals(savedUsername, ignoreCase = true) ||
            !MessageDigest.isEqual(expected, hash(password, salt))) {
            binding.passwordInput.text?.clear()
            return showError("Username or password is incorrect.")
        }
        AppSession.unlocked = true
        openCamera()
    }

    private fun hash(password: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(password.toCharArray(), salt, 120_000, 256)).encoded

    private fun showError(message: String) { binding.errorText.text = message }

    private fun openCamera() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
