package com.codibaker.camerasimple

object AppSession {
    var unlocked: Boolean = false
}
